Đây là cơ sở dữ liệu địa giới hành chính của Việt Nam.
Cơ sở dữ liệu này chi tiết tới cấp Xã/Phường/Thị Trấn.
Cơ sở dữ liệu này được tổng hợp từ Wikipedia bởi Vũ Thanh Lai (facebook.com/vuthanhlai)
và được chia sẻ tại diễn đàn sinhvienit.net

Lưu ý:
Các mã địa giới (ID trong các bảng) không phải là Id được sinh ngẫu nhiên, đó là mã địa giới chính thức được ban hành theo quyết định số 124/2004/QĐ-TTg của chính phủ vào ngày 08/7/2004.

==================
http://sinhvienit.net/
Cộng đồng những người yêu thích hoặc theo học ngành CNTT
=================== 